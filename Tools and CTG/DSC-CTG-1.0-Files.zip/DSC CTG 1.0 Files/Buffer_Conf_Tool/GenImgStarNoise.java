/*
 * Copyright (c) 2014 Qualcomm Technologies, Inc.
 * All Rights Reserved.
 *
*/
 
/*
Star Noise Image Sequence Generator

Sample run command: java GenImgStarNoise config.txt starnoise_ 10 1
This generates starnoise_00000.png, ..., starnoise_00009.png in the current directory.

Sample config file:
================================================================================
%	Width	Height	BitsPerComponent	MinOfScale	MaxOfScale	NumOfPatterns	Background level
	640		480		8					0			255			1				128 128 128
%
%
% Each pattern has the following parameters: 
% CX:	Ring's center X coordinate in pixels
% CY:	Ring's center Y coordinate in pixels
% RI:	Ring's inner radius in pixels
% RO:	Ring's outer radius in pixels
% Fs:	Sampling period measured in [1/radian]
% NFR:	Red channel's normalized period - F/Fs
% NFG:	Green channel's normalized period - F/Fs
% NFB:	Blue channel's normalized period - F/Fs
% PR:	Red channel's phase - multiple of PI(e.g. 0.5 for PI/2)
% PG:	Green channel's phase - multiple of PI(e.g. 0.5 for PI/2)
% PB:	Blue channel's phase - multiple of PI(e.g. 0.5 for PI/2)
%
%	Pattern data table
%	
%	CX	CY	RI	RO	NFR	NFG	NFB	PR	PG	PB
	380	210	15	190	3	5	2	0.0	0.1	0.2
================================================================================
*/

import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
import javax.imageio.ImageIO;


public class GenImgStarNoise {
	
	public static void main(String[] args) throws IOException {
		// Handle and parse arguments
		if (args.length < 2 || args.length > 4) {
			System.err.println("Usage: java GenImgStarNoise Config.cfg OutputImagePrefix [NumFrames] [Noise]");
			System.exit(1);
			return;
		}
		Config config = readConfig(new File(args[0]));
		String outputPrefix = args[1];
		int numFrames = args.length <= 2 ? 1 : Integer.parseInt(args[2]);
		boolean enableNoise = args.length <= 3 ? false : Integer.parseInt(args[3]) != 0;
		
		// Configuration calculations
		int width = config.imageWidth;
		int height = config.imageHeight;
		// Co and Cg channels have 1 extra bit than the declared bit width
		int[] bitWidths = {config.bitsPerComponent, config.bitsPerComponent + 1, config.bitsPerComponent + 1};
		int[] minVals = {config.minVal, config.minVal << 1, config.minVal << 1};
		int[] maxVals = {config.maxVal, config.maxVal << 1, config.maxVal << 1};
		
		// Generated and save each frame
		Rand rand = new Rand(0);
		for (int k = 0; k < numFrames; k++) {
			// Initialize raster with uniform color
			Raster raster = new Raster(width, height, config.bitsPerComponent);
			for (int y = 0; y < height; y++) {
				for (int x = 0; x < width; x++) {
					int index = y * width + x;
					raster.values[0][index] = config.background[0];       // Y
					raster.values[1][index] = config.background[1] << 1;  // Co
					raster.values[2][index] = config.background[2] << 1;  // Cg
				}
			}
			
			// Overwrite raster with noise
			if (enableNoise) {
				for (int y = 0; y < height; y++) {
					for (int x = 0; x < width; x++) {
						for (int c = 0; c < 3; c++) {
							raster.values[c][y * width + x] = ((1 << bitWidths[c]) - 1) * rand.rand() / Rand.MAX;  // Requires bitWidth[c] <= 15, otherwise overflow
							// Or use java.util.Random.nextInt(1 << bitWidths[c])
						}
					}
				}
			}
			
			// Paint circles onto raster
			for (CosParam pat : config.patterns)
			{
				pat.phases[0] += 0.01;
				pat.phases[1] += 0.01;
				pat.phases[2] += 0.01;
				GetCosCircle(pat, bitWidths, minVals, maxVals, raster);
			}
			
			// Convert pixels from YCoCg to RGB
			Pixel pixin = new Pixel();
			Pixel pixout = new Pixel();
			for (int y = 0; y < height; y++) {
				for (int x = 0; x < width; x++) {
					int index = y * width + x;
					pixin.a = raster.values[0][index];
					pixin.b = raster.values[1][index];
					pixin.c = raster.values[2][index];
					ycocgToRgb(pixin, pixout, raster.bitWidth);
					raster.values[0][index] = pixout.a;
					raster.values[1][index] = pixout.b;
					raster.values[2][index] = pixout.c;
				}
			}
			
			// Write raster image to the output file
			File outfile = new File(String.format("%s%05d.png", outputPrefix, k));
			ImageIO.write(rasterToImage(raster, raster.bitWidth), "png", outfile);
		}
	}
	
	
	private static Config readConfig(File file) throws IOException {
		final double PI = 3.14;
		BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream(file)));
		try {
			Config cfg = new Config();
			
			// Skip lines starting with '%'
			String line;
			do line = in.readLine();
			while (line.startsWith("%"));
			
			// Parse line of image parameters
			String[] toks = line.split("\\s+", 0);
			if (toks[0].equals(""))
				toks = Arrays.copyOfRange(toks, 1, toks.length);
			cfg.imageWidth       = Integer.parseInt(toks[0]);
			cfg.imageHeight      = Integer.parseInt(toks[1]);
			cfg.bitsPerComponent = Integer.parseInt(toks[2]);
			cfg.minVal           = Integer.parseInt(toks[3]);
			cfg.maxVal           = Integer.parseInt(toks[4]);
			int numPatterns      = Integer.parseInt(toks[5]);
			cfg.background[0]    = Integer.parseInt(toks[6]);
			cfg.background[1]    = Integer.parseInt(toks[7]);
			cfg.background[2]    = Integer.parseInt(toks[8]);
			
			cfg.patterns = new CosParam[numPatterns];
			for (int i = 0; i < cfg.patterns.length; i++) {
				// Skip lines starting with '%'
				do line = in.readLine();
				while (line.startsWith("%"));
				
				CosParam p = new CosParam();
				toks = line.split("\\s+");
				if (toks[0].equals(""))
					toks = Arrays.copyOfRange(toks, 1, toks.length);
				p.centerX    = Integer.parseInt(toks[0]);
				p.centerY    = Integer.parseInt(toks[1]);
				p.radiusMin  = Integer.parseInt(toks[2]);
				p.radiusMax  = Integer.parseInt(toks[3]);
				p.periods[0] = Double.parseDouble(toks[4]);
				p.periods[1] = Double.parseDouble(toks[5]);
				p.periods[2] = Double.parseDouble(toks[6]);
				p.phases[0]  = Double.parseDouble(toks[7]) * PI;
				p.phases[1]  = Double.parseDouble(toks[8]) * PI;
				p.phases[2]  = Double.parseDouble(toks[9]) * PI;
				cfg.patterns[i] = p;
			}
			
			return cfg;
			
		} finally {
			in.close();
		}
	}
	
	
	private static void GetCosCircle(CosParam param, int[] bitWidths, int[] minVals, int[] maxVals, Raster raster) {
		double[] halfRange = new double[3];
		for (int c = 0; c < 3; c++)
			halfRange[c] = (maxVals[c] - minVals[c] + 1) / 2.0;
		
		// Find bounding box left top coordinate
		int leftX = param.centerX - param.radiusMax;
		int topY  = param.centerY - param.radiusMax;
		
		int width = raster.width;
		int height = raster.height;
		if (leftX < 0 || topY < 0 || (leftX + 2 * param.radiusMax > width) || (topY + 2 * param.radiusMax > height))
			throw new IllegalArgumentException("Invalid ring parameters - ring crosses image boundaries");
		
		for (int y = 0; y < height; y++) {
			for (int x = 0; x < width; x++) {
				if ((y >= topY) && (y < topY + 2 * param.radiusMax) && (x >= leftX) && (x < leftX + 2 * param.radiusMax)) {
					int cx = x - param.centerX;
					int cy = y - param.centerY;
					double radius = Math.hypot(cx, cy);
					// Test whether current pixel belongs to the ring or not
					if (param.radiusMin <= radius && radius <= param.radiusMax) {
						double dk = param.radiusMin * (Math.atan2(cy, -cx) + Math.PI);	// 0 <-> 2
						for (int c = 0; c < 3; c++) {
							double frequency = (param.periods[c] > 0) ? 1.0 / param.periods[c] : 0;
							double cos = Math.cos(2 * Math.PI * (dk * frequency + param.phases[c]));
							double temp = (cos + 1) * halfRange[c] + minVals[c];
							raster.values[c][y * width + x] = clamp((int)(temp + 0.5), 0, (1 << bitWidths[c]) - 1);
						}
					}
				}
			}
		}
	}
	
	
	// Output is 8 bits per channel
	private static BufferedImage rasterToImage(Raster raster, int bitWidth) {
		int width = raster.width;
		int height = raster.height;
		int[] temp = new int[width * height];
		for (int y = 0; y < height; y++) {
			for (int x = 0; x < width; x++) {
				int index = y * width + x;
				int r = raster.values[2][index] >>> (bitWidth - 8);
				int g = raster.values[0][index] >>> (bitWidth - 8);
				int b = raster.values[1][index] >>> (bitWidth - 8);
				if (((r | g | b) & ~0xFF) != 0)
					throw new IllegalArgumentException("Pixel value out of range [0,256)");
				temp[index] = r << 16 | g << 8 | b;
			}
		}
		
		BufferedImage result = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
		result.setRGB(0, 0, width, height, temp, 0, width);
		return result;
	}
	
	
	private static void ycocgToRgb(Pixel in, Pixel out, int bitWidth) {
		int range = 1 << bitWidth;
		int limit = range - 1;
		
		int y = in.a;
		int co = in.b - range;
		int cg = in.c - range;
		int t = y - (cg >> 1);
		
		int g = cg + t;
		int b = t - (co >> 1);
		int r = b + co;
		out.a = clamp(g, 0, limit);
		out.b = clamp(b, 0, limit);
		out.c = clamp(r, 0, limit);
	}
	
	
	private static int clamp(int x, int low, int high) {
		if (x < low)
			return low;
		else if (x > high)
			return high;
		else
			return x;
	}
	
	
	
	private static class Config {
		
		public int imageWidth;
		public int imageHeight;
		public int bitsPerComponent;
		public int minVal;
		public int maxVal;
		public int[] background = new int[3];
		public CosParam[] patterns;
		
	}
	
	
	
	private static class CosParam {
		
		public int radiusMin;
		public int radiusMax;
		public int centerX;
		public int centerY;
		public double[] periods = new double[3];
		public double[] phases = new double[3];
		
	}
	
	
	
	// A 3-channel image with up to signed 32 bits per channel
	private static class Raster {
		
		public int width;
		public int height;
		public int bitWidth;
		public int[][] values;
		
		
		public Raster(int width, int height, int bitWidth) {
			this.width = width;
			this.height = height;
			this.bitWidth = bitWidth;
			values = new int[3][width * height];
		}
		
	}
	
	
	
	// Ordering used: GBR or YUV
	private static class Pixel {
		
		public int a;
		public int b;
		public int c;
		
	}
	
	
	
	// Bit-accurate emulation of Visual C++ runtime's srand() and rand()
	private static class Rand {
		
		public static final int MAX = 0x7FFF;
		
		private int state;
		
		public Rand(int seed) {
			state = seed;
		}
		
		public int rand() {
			state = state * 214013 + 2531011;
			return (state >>> 16) & MAX;
		}
		
	}
	
}
