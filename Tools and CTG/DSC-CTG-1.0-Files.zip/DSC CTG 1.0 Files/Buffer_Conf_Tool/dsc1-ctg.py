#
# Copyright (c) 2014 Qualcomm Technologies, Inc.
# All Rights Reserved.
#

#
# DSC 1.31 runner for Conformance Test Guideline
#
# Usage: python dsc1-ctg.py
#

import math, os, shutil, subprocess, sys, time, ConfigParser, csv, CRC

def main(ini_filename):

    # Parse INI file
    Config = ConfigParser.ConfigParser(allow_no_value=True)
    Config.read(os.path.join(os.getcwd(),ini_filename))

    picturetype_list, bpc, configdir, baselogfilename, outputdir, src, comp, reconst, table_list = initialize_parameters(Config)

    # Iterate through the table and picture type
    for table in table_list:

        table_name = table.split('.')[0]
        table_num = table_name.split()[1]
        logfilename = baselogfilename + "_" + table_num + ".txt"
        cmdfilename = baselogfilename + "_" + table_num + " commands.txt"
        # Initialize BPP
        bpp = table_name.split()[3]
        # Initialize UseSplit
        usesplit = table_name.split()[4]
        assert usesplit in ("NoSplit", "Split")
        if usesplit == "Split":
            usesplit = True
        else:
            usesplit = False

        # Progress message
        print("Starting process for %s" % (table_name))

        tableoutputdir = os.path.join(outputdir,table_name)
        if not os.path.exists(tableoutputdir):
            os.mkdir(tableoutputdir)
        with open(os.path.join(tableoutputdir, cmdfilename), "w") as cmdfile:
            with open(os.path.join(tableoutputdir, logfilename), "w") as logfile:
                # Write the header in logfile
                if usesplit:
                    header_string = '{0:8}{1:12}{2:10}{3:15}{4:20}{5:15}{6:10}{7:10}{8:18}{9:18}{10:18}{11:18}{12:18}{13:18}\n'.format('Table','Picture Type','# Slices','Slice Height',
                                                                                                                                        'Valid Slice Size','Valid Height','Width','Height',
                                                                                                                                        'Orig CRC Left', 'Comp CRC Left','Uncomp CRC Left',
                                                                                                                                        'Orig CRC Right', 'Comp CRC Right','Uncomp CRC Right')
                else:
                    header_string = '{0:8}{1:12}{2:10}{3:15}{4:20}{5:15}{6:10}{7:10}{8:18}{9:18}{10:18}\n'.format('Table','Picture Type','# Slices','Slice Height','Valid Slice Size',
                                                                                                                    'Valid Height','Width','Height','Orig CRC','Comp CRC','Uncomp CRC')
                logfile.write(header_string)

                parsed_data = []
                with open(os.path.join(os.getcwd(),Config.get('InputDirName','Table'),table),"rb") as fin:
                    reader = csv.reader(fin)
                    for line in reader:
                        parsed_data.append(line)
                for picturetype in picturetype_list:
                    pictureoutputdir = os.path.join(tableoutputdir,picturetype)
                    if not os.path.exists(pictureoutputdir):
                        os.mkdir(pictureoutputdir)
                    for (horzslices, sliceheight, valid0, valid1, width, height) in parsed_data:
                        logfile.write("{0:8}{1:12}{2:10}{3:15}{4:20}{5:15}{6:10}{7:10}".format(table_num, picturetype, horzslices, sliceheight, valid0, valid1, width, height))

                        if valid0 == "Valid" and valid1 == "Valid":
                            run_dsc1(picturetype, int(width), int(height), int(horzslices), int(sliceheight), bpp, bpc, pictureoutputdir, "dsc1-temp", logfile, cmdfile, src, comp, reconst, configdir, usesplit)
                        else:
                            if usesplit:
                                logfile.write("{0:18}{1:18}{2:18}{3:18}{4:18}{5:18}\n".format('-','-','-','-','-','-'))
                            else:
                                logfile.write("{0:18}{1:18}{2:18}\n".format('-','-','-'))
                            cmdfile.write("-\n")
                            cmdfile.flush()
                            logfile.flush()

def run_dsc1(intype, width, height, horzslices, sliceheight, bpp, bpc, outdir, tempdir, logfile, cmdfile, src, comp, reconst, configdir, usesplit):
    try:
        srcoutdir, compoutdir, reconstoutdir = generate_directories(outdir, tempdir, src, comp, reconst)

        if usesplit:
            # Double the width as the input width in the file is only half of the width
            width *= 2

        inputfile = generate_input_picture(intype, width, height, tempdir, srcoutdir)
        infile_list = generate_split(usesplit, intype, inputfile, tempdir, srcoutdir, width, height)

        for filename in infile_list:
            infile = os.path.join(srcoutdir, filename + '.png')

            # Convert picture to raw, and calculate CRC-16
            convert_picture_to_raw(infile, os.path.join(srcoutdir, filename + '.raw'))
            calc_crc(0, logfile, os.path.join(srcoutdir, filename + '.raw'), os.path.join(srcoutdir, filename + '.crc'))

            # Convert picture to temporary DPX
            tempfile = os.path.join(tempdir, "picture.dpx")
            convert_picture_to_dpx(infile, tempfile)

            # Generate parameters for DSC-1, compress, and calculate CRC
            cfgfile = set_up_parameters_for_dsc1(tempdir, tempfile, configdir, bpp, bpc, width, horzslices) # Need to include bpc into the ini file as well

            compress_with_dsc1(cfgfile, width, horzslices, sliceheight, tempdir, cmdfile)
            # For .dsc file, use modified CRC function, remove first 132 bytes
            calc_crc(132, logfile, os.path.join(tempdir, "picture.dsc"), os.path.join(compoutdir, filename + "_%dx%d.crc" % (horzslices, sliceheight)))
            # Rename the temporary output file to its proper name
            os.rename(os.path.join(tempdir, "picture.dsc"), os.path.join(compoutdir, filename + "_%dx%d.dsc" % (horzslices, sliceheight)))

            # Decompress with DSC-1
            decompress_with_dsc1(cfgfile, width, horzslices, sliceheight, tempdir, cmdfile)

            # Convert DPX -> raw, and calculate CRC-16
            convert_dpx_to_raw(os.path.join(tempdir, "picture.out.dpx"), os.path.join(reconstoutdir, filename + "_%dx%d.raw" % (horzslices, sliceheight)))
            calc_crc(0, logfile, os.path.join(reconstoutdir, filename + "_%dx%d.raw" % (horzslices, sliceheight)), os.path.join(reconstoutdir, filename + "_%dx%d.crc" % (horzslices, sliceheight)))

            # Convert RAW -> PNG
            # Starting from RAW otherwise R&B inversion cannot be corrected with DPX as source
            outfile = os.path.join(reconstoutdir, filename + "_%dx%d.png" % (horzslices, sliceheight))
            if usesplit:
                convert_raw_to_png(os.path.join(reconstoutdir, filename + "_%dx%d.raw" % (horzslices, sliceheight)), outfile, width/2, height)
            else :
                convert_raw_to_png(os.path.join(reconstoutdir, filename + "_%dx%d.raw" % (horzslices, sliceheight)), outfile, width, height)

        # Flush Log file and closes it
        logfile.write("\n")
        logfile.flush()
        cmdfile.flush()

    finally:  # Clean up:
        delay = 0.1
        while delay < 10:
            try:
                shutil.rmtree(tempdir)
                break
            except WindowsError:  # Stupid random "[Error 32] The process cannot access the file because it is being used by another process"
                time.sleep(delay)
            delay *= 2  # Exponential backoff

# ---- Subprocess functions ----
# Initializes variables with parameter values specified in the dsc.ini file
def initialize_parameters(Config):

    # Sets the parameters based on the information on the INI file
    picturetype_list = [result.strip() for result in Config.get('TestPattern','picturetype').split(',')]

    bpc = Config.get('Bpc','bpc')

    configdir = Config.get('InputDirName','Config')
    logfilename = Config.get('LogName','logfile')
    outputdir = Config.get('TopDirName','Top')

    if not os.path.exists(outputdir):
        os.mkdir(outputdir)

    # Get the name of the source, compressed, decompressed directory.
    src = Config.get('SubDirName','src')
    comp = Config.get('SubDirName','comp')
    reconst = Config.get('SubDirName','reconst')

    table_list = [result.strip() for result in Config.get('TableName','table').split(',')]
    return picturetype_list, bpc, configdir, logfilename, outputdir, src, comp, reconst, table_list

# Generate directories
def generate_directories(outdir, tempdir, src, comp, reconst):
    os.mkdir(tempdir)

    # Make Source directory
    srcoutdir = os.path.join(outdir,src)
    if not os.path.exists(srcoutdir):
            os.mkdir(srcoutdir)

    # Make Compress directory
    compoutdir = os.path.join(outdir,comp)
    if not os.path.exists(compoutdir):
        os.mkdir(compoutdir)

    # Make Decompress directory
    reconstoutdir = os.path.join(outdir,reconst)
    if not os.path.exists(reconstoutdir):
        os.mkdir(reconstoutdir)
    return srcoutdir, compoutdir, reconstoutdir

# Generate Source Input Picture
# Need to move these values into the INI file?!
def generate_input_picture(intype, width, height, tempdir, srcoutdir):
    inputfile = os.path.join(srcoutdir, "%s_%dx%d.png" % (intype, width, height))
    if intype == "starnoise":
        cfgfile = os.path.join(tempdir, "starnoise.cfg")
        with open(cfgfile, "w") as fout:
            print >>fout, "%d %d %d %d %d %d %d %d %d" % (width, height, 8, 0, 255, 1, 128, 128, 128)
            print >>fout, "%d %d %d %d %d %d %d %f %f %f" % (width // 2, height // 2, int(round(math.sqrt(width * height) / 72)), min(width, height) // 2, 3, 3, 3, 0.0, 0.1, 0.2)
        subprocess.check_call(["java", "-cp", os.path.abspath("."), "GenImgStarNoise", os.path.abspath(cfgfile), "star", "1", "1"], cwd=tempdir)
        tempfile = os.path.join(tempdir, "star00000.png")
        assert os.path.isfile(tempfile)
        if os.path.isfile(inputfile):
            os.remove(inputfile)
        os.rename(tempfile, inputfile)
    elif intype == "colorbars":
        subprocess.check_call(["convert", os.path.abspath("colorbars.png"), "-sample", "%dx%d!" % (width, height), inputfile])
    else:
        raise ValueError()

    return inputfile

# Generate split pictures if needed
def generate_split(usesplit, intype, inputfile, tempdir, srcoutdir, width, height):
# Split the generated input picture if needed
    infile_list = []
    if usesplit:
        split_pictures = split_picture_vertical(inputfile, tempdir)
        leftfile = os.path.join(srcoutdir, "%s_%dx%d_left.png" % (intype, width, height))
        rightfile = os.path.join(srcoutdir, "%s_%dx%d_right.png" % (intype, width, height))
        # Copy and rename the split pictures into source folder if the source pictures have not already been generated
        if not os.path.isfile(leftfile):
            os.rename(split_pictures[0], leftfile)
        if not os.path.isfile(rightfile):
            os.rename(split_pictures[1], rightfile)
        # Assign the infile names
        infile_list.append("%s_%dx%d_left" % (intype, width, height))
        infile_list.append("%s_%dx%d_right" % (intype, width, height))
    else:
        infile_list.append("%s_%dx%d" % (intype, width, height))

    return infile_list



# Set up parameters for dsc-1
def set_up_parameters_for_dsc1(tempdir, tempfile, configdir, bpp, bpc, width, horzslices):
    # Set up parameters
    with open(os.path.join(tempdir, "test_list.txt"), "w") as f:
        f.write(os.path.abspath(tempfile) + "\n")
    rcfile = os.path.join(configdir, "rc_%s_%s.cfg" % (bpc, bpp))
    shutil.copyfile(rcfile, os.path.join(tempdir, os.path.basename(rcfile)))
    if width % horzslices != 0:
        raise ValueError("Width not divisible by slices")
    cfgfile = os.path.join(configdir, "test_%s_%s.cfg" % (bpc, bpp))
    return cfgfile



# ---- Utility methods ----

# Converts the given picture file to a DPX picture file at the given output file name.
def convert_picture_to_dpx(infile, outfile):
    subprocess.check_call([
        "convert",
        infile,
        "-type", "TrueColor",
        outfile])

# Converts the given picture file to a raw picture file at the given output file name.
def convert_picture_to_raw(infile, outfile):
    subprocess.check_call([
        "convert",
        infile,
        "-depth", "8",
        "rgb:" + outfile])

# Converts the STD DPX picture file to a raw picture file at the given output file name.
# ImageMagick Convert produces R&B inversion that must be corrected
# Also, color profile must be specified as RGB for source image
# and no conversion for destination, otherwise ImageMagick (>6.8.x)
# sees C-model DPXs as non-linear sRGB (because not explicitly
# identified in DPX header)
def convert_dpx_to_raw(infile, outfile):
    subprocess.check_call([
        "convert",
        "-set", "colorspace",  "sRGB",   #INVESTIGATING  JDH
        infile,
        "-depth", "8",
        "-colorspace", "sRGB",	#INVESTIGATING  JDH
        "bgr:" + outfile])


# Converts the given raw picture file with the given width and height into a PNG file at the given output file name.
def convert_raw_to_png(infile, outfile, width, height):
    subprocess.check_call([
        "convert",
        "-size",
        str(width)+"x"+str(height),
        "-depth", "8",
        "rgb:" + infile,
        "png24:" + outfile])

# Splits the given picture file into two pictures by dividing them vertically into left and right halves.
def split_picture_vertical(infile, tempdir):
    subprocess.check_call([
        "convert",
        infile,
        "-crop", "50%x100%",
        "+repage",
        os.path.join(tempdir, "picture_%d.png")
        ])
    # Returns the file path of the two split pictures
    output_list = [os.path.join(tempdir, "picture_0.png"), os.path.join(tempdir, "picture_1.png")]
    return output_list

# Calculates CRC values
def calc_crc(start, logfile, rawdir, crcdir):
    with open(rawdir, "rb") as fin:
        read_data = fin.read()
        crc_value = CRC.CRC(read_data[start:])
        logfile.write("{0:18}".format("%04X" % crc_value))
        # Create and write a CRC file
        crcfile = open(crcdir, "w")
        crcfile.write("%04X\t" % crc_value)
        crcfile.close()

# Run DSC-1 compression
def compress_with_dsc1(cfgfile, width, horzslices, sliceheight, tempdir, cmdfile):
    # Run DSC-1 model, calculate CRC-16 of bitstream
    subprocess.check_call([
            os.path.abspath("DSC"),
            "-F", os.path.abspath(cfgfile),
            "-OFUNCTION 1",
            "-ODPX_BUGS_OVERRIDE 2",
            "-OSLICE_WIDTH %d" % (width // horzslices),
            "-OSLICE_HEIGHT %d" % sliceheight],
        cwd=tempdir)
    # Write to the command logfile
    cmdfile.write("%s -F %s -OFUNCTION 1 -ODPX_BUGS_OVERRIDE 2 -OSLICE_WIDTH %d -OSLICE_HEIGHT %d \n" %
            (str(os.path.abspath("DSC")), str(os.path.abspath(cfgfile)), (width // horzslices), sliceheight))
    return

# Run DSC-1 decompression
def decompress_with_dsc1(cfgfile, width, horzslices, sliceheight, tempdir, cmdfile):
    subprocess.check_call([
            os.path.abspath("DSC"),
            "-F", os.path.abspath(cfgfile),
            "-ODPX_BUGS_OVERRIDE 2",
            "-OSLICE_WIDTH %d" % (width // horzslices),
            "-OSLICE_HEIGHT %d" % sliceheight],
        cwd=tempdir)
    # Write to the command logfile
    cmdfile.write("%s -F %s -ODPX_BUGS_OVERRIDE 2 -OSLICE_WIDTH %d -OSLICE_HEIGHT %d \n"
        % (str(os.path.abspath("DSC")), str(os.path.abspath(cfgfile)), (width // horzslices), sliceheight))
    return

if __name__ == "__main__":
    main('dsc.ini')
