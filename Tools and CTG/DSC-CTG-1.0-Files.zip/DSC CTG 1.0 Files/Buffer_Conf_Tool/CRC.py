#
# Copyright (c) 2014 Qualcomm Technologies, Inc.
# All Rights Reserved.

#
# CRC.py 
#

def CRC(bytedata):
    POLYNOMIAL = 0x18005
    DEGREE = POLYNOMIAL.bit_length() - 1
    assert type(bytedata) == str    
    state = 0
    therange = range(8)
    for b in bytedata:
        state ^= ord(b) << (DEGREE - 8)
        for i in therange:
            state <<= 1
            state ^= POLYNOMIAL * (state >> DEGREE)
    return state
