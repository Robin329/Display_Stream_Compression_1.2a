#!\usr\bin\python

# source file: buffer_stress_2560x1920x08bpc.ppm
# 08 bpc
# 444 mode
# slice height = 16
# slice width = 1280
# altINV = off

import os, sys, shutil, subprocess
sourcePath =      '\Users\userName\Desktop\DSC_Test\Scripts\444 YCbCr 8 bit Feeder 16x1280\'

autoScriptFile =  '\Users\userName\Desktop\DSC_Test\DSC_model_20160912\auto_script.cfg'
outputImageFile = '\Users\userName\Desktop\DSC_Test\DSC_model_20160912\buffer_stress_2560x1920x08bpc.out.dpx'
destImageFile =   '\Users\userName\Desktop\DSC_Test\Results\444 YCbCr 08bpc buffer_stress_16x1280\Buffer_Stress-'

dirs = os.listdir( sourcePath )

for file in dirs:
  if not file.startswith('.'):     # to ignore UNIX\macOS hidden files starting with '.'

    if os.path.exists(autoScriptFile):
      os.remove(autoScriptFile)

    sourceFile = os.path.join(sourcePath, file)
    shutil.copy(sourceFile, autoScriptFile)

    subprocess.call('\Users\userName\Desktop\DSC_Test\DSC_model_20160912\dsc_mac -F test.cfg', shell=True)

    outputFileName = destImageFile + file[:-3]

    shutil.copy(outputImageFile + 'dpx', outputFileName + 'dpx')
    shutil.copy(outputImageFile + 'ppm', outputFileName + 'ppm')
    shutil.copy(outputImageFile + 'yuv', outputFileName + 'yuv')

#    raw_input("Press Enter to continue...")


